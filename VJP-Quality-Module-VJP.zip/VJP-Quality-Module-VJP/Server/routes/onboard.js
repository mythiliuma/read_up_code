var express = require('express')
const router = express.Router();
const { User } = require('./../model')


module.exports = router;