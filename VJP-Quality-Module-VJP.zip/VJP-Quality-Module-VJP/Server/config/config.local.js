var path = require('path');
var config = {}
config.env = 'local';
config.dbhost = "localhost";
config.username = "root";
config.password = "";
config.db = "pagupu";
config.logging = true;
config.port = 3000;
config.JWT_SECRET = "welcometoironman";

config.email = "mastergit.vjp@gmail.com"

config.oauth_refresh_token = 'ya29.Il-7BwTiwOqiHymoeNh96YDnutnuUd1E7p7uwD9dhP--RjllL764hB83X7ejIADzH_ttsimysb2gZss4dbKlri67Bs1AyhQxXFeB49GPUpzOHi-OcGA3EvTTPgKZKLWCwA'

config.oauth_client_id = "749043574836-v2aujkdilmplp2m13hsbii4j0rg8nf0e.apps.googleusercontent.com";

config.oauth_client_secret = 'hebr6Cl4SuSKyxVplUhwlwaV'

module.exports = config;
