// var env = process.env.NODE_ENV || 'local';
var env = 'local';
var cfg = require('./config.local');
module.exports = cfg;